If you're having trouble with OSMnx, please open an issue at the OSMnx repo: https://github.com/gboeing/osmnx/issues

Any issues opened here **will be automatically closed** unless they are proposals for new examples or demos, or suggestions for the existing ones.

PRs welcome for new examples!
